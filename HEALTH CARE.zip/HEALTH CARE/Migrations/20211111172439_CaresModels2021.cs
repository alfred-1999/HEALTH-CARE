﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace HEALTH_CARE.Migrations
{
    public partial class CaresModels2021 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Bios",
                columns: table => new
                {
                    BioId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Username = table.Column<string>(nullable: false),
                    Password = table.Column<string>(nullable: false),
                    Name = table.Column<string>(nullable: false),
                    Surname = table.Column<string>(nullable: false),
                    IDNo = table.Column<string>(nullable: false),
                    Cellphone = table.Column<string>(nullable: true),
                    MedicalNo = table.Column<string>(nullable: true),
                    Owner = table.Column<string>(nullable: true),
                    SuburbName = table.Column<string>(nullable: true),
                    MedicalType = table.Column<string>(nullable: true),
                    MedicalPlan = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Bios", x => x.BioId);
                });

            migrationBuilder.CreateTable(
                name: "CaptureResult",
                columns: table => new
                {
                    CapId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Results = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CaptureResult", x => x.CapId);
                });

            migrationBuilder.CreateTable(
                name: "Citys",
                columns: table => new
                {
                    CityId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    cityName = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Citys", x => x.CityId);
                });

            migrationBuilder.CreateTable(
                name: "Funds",
                columns: table => new
                {
                    FundId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MedicalAid = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Funds", x => x.FundId);
                });

            migrationBuilder.CreateTable(
                name: "Nurses",
                columns: table => new
                {
                    NurseId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FullName = table.Column<string>(nullable: false),
                    Surname = table.Column<string>(nullable: false),
                    CellNumber = table.Column<string>(nullable: false),
                    Email = table.Column<string>(nullable: false),
                    Date = table.Column<string>(nullable: false),
                    SuburbName = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Nurses", x => x.NurseId);
                });

            migrationBuilder.CreateTable(
                name: "Timeslots",
                columns: table => new
                {
                    TimeId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TimeRange = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Timeslots", x => x.TimeId);
                });

            migrationBuilder.CreateTable(
                name: "Suburbs",
                columns: table => new
                {
                    SuburbId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SuburbName = table.Column<string>(nullable: false),
                    cityName = table.Column<string>(nullable: true),
                    CityId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Suburbs", x => x.SuburbId);
                    table.ForeignKey(
                        name: "FK_Suburbs_Citys_CityId",
                        column: x => x.CityId,
                        principalTable: "Citys",
                        principalColumn: "CityId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Aidtbl",
                columns: table => new
                {
                    MedicalId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MedicalPlan = table.Column<string>(nullable: false),
                    MedicalAid = table.Column<string>(nullable: true),
                    MedicalAidFundFundId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Aidtbl", x => x.MedicalId);
                    table.ForeignKey(
                        name: "FK_Aidtbl_Funds_MedicalAidFundFundId",
                        column: x => x.MedicalAidFundFundId,
                        principalTable: "Funds",
                        principalColumn: "FundId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Payments",
                columns: table => new
                {
                    PaymentId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Date = table.Column<string>(nullable: true),
                    NurseName = table.Column<string>(nullable: true),
                    NurseId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Payments", x => x.PaymentId);
                    table.ForeignKey(
                        name: "FK_Payments_Nurses_NurseId",
                        column: x => x.NurseId,
                        principalTable: "Nurses",
                        principalColumn: "NurseId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "FavouriteSuburb",
                columns: table => new
                {
                    FavId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NurseName = table.Column<string>(nullable: true),
                    SuburbName = table.Column<string>(nullable: true),
                    SuburbId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FavouriteSuburb", x => x.FavId);
                    table.ForeignKey(
                        name: "FK_FavouriteSuburb_Suburbs_SuburbId",
                        column: x => x.SuburbId,
                        principalTable: "Suburbs",
                        principalColumn: "SuburbId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "lABUSERs",
                columns: table => new
                {
                    LabId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Date = table.Column<string>(nullable: false),
                    NurseName = table.Column<string>(nullable: true),
                    RequestId = table.Column<string>(nullable: true),
                    TimeRange = table.Column<string>(nullable: true),
                    SuburbId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_lABUSERs", x => x.LabId);
                    table.ForeignKey(
                        name: "FK_lABUSERs_Suburbs_SuburbId",
                        column: x => x.SuburbId,
                        principalTable: "Suburbs",
                        principalColumn: "SuburbId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Dependents",
                columns: table => new
                {
                    DependentId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IDNo = table.Column<string>(nullable: false),
                    DepName = table.Column<string>(nullable: false),
                    DepSurname = table.Column<string>(nullable: false),
                    Cellphone = table.Column<string>(nullable: false),
                    Email = table.Column<string>(nullable: false),
                    DependentAddress = table.Column<string>(nullable: true),
                    Description = table.Column<string>(nullable: true),
                    MedicalType = table.Column<string>(nullable: true),
                    MedicalNo = table.Column<string>(nullable: true),
                    Owner = table.Column<string>(nullable: true),
                    MedicalPlan = table.Column<string>(nullable: true),
                    MedicalAidtblMedicalId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Dependents", x => x.DependentId);
                    table.ForeignKey(
                        name: "FK_Dependents_Aidtbl_MedicalAidtblMedicalId",
                        column: x => x.MedicalAidtblMedicalId,
                        principalTable: "Aidtbl",
                        principalColumn: "MedicalId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Requests",
                columns: table => new
                {
                    RequestId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Testfor = table.Column<string>(nullable: false),
                    TodaysDate = table.Column<string>(nullable: false),
                    NewAddress = table.Column<string>(nullable: true),
                    MainFullName = table.Column<string>(nullable: false),
                    IDNo = table.Column<string>(nullable: false),
                    Time = table.Column<string>(nullable: true),
                    MediStatus = table.Column<string>(nullable: false),
                    Status = table.Column<string>(nullable: false),
                    Email = table.Column<string>(nullable: false),
                    DepName = table.Column<string>(nullable: true),
                    DependentId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Requests", x => x.RequestId);
                    table.ForeignKey(
                        name: "FK_Requests_Dependents_DependentId",
                        column: x => x.DependentId,
                        principalTable: "Dependents",
                        principalColumn: "DependentId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Screenings",
                columns: table => new
                {
                    ScreeningId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Patient = table.Column<string>(nullable: false),
                    Temperature = table.Column<string>(nullable: false),
                    BloodPressure = table.Column<string>(nullable: false),
                    Oxygen = table.Column<int>(nullable: false),
                    Barcode = table.Column<string>(nullable: false),
                    IDNo = table.Column<string>(nullable: false),
                    Results = table.Column<string>(nullable: true),
                    CaptureResultsCapId = table.Column<int>(nullable: true),
                    DependentId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Screenings", x => x.ScreeningId);
                    table.ForeignKey(
                        name: "FK_Screenings_CaptureResult_CaptureResultsCapId",
                        column: x => x.CaptureResultsCapId,
                        principalTable: "CaptureResult",
                        principalColumn: "CapId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Screenings_Dependents_DependentId",
                        column: x => x.DependentId,
                        principalTable: "Dependents",
                        principalColumn: "DependentId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Aidtbl_MedicalAidFundFundId",
                table: "Aidtbl",
                column: "MedicalAidFundFundId");

            migrationBuilder.CreateIndex(
                name: "IX_Dependents_MedicalAidtblMedicalId",
                table: "Dependents",
                column: "MedicalAidtblMedicalId");

            migrationBuilder.CreateIndex(
                name: "IX_FavouriteSuburb_SuburbId",
                table: "FavouriteSuburb",
                column: "SuburbId");

            migrationBuilder.CreateIndex(
                name: "IX_lABUSERs_SuburbId",
                table: "lABUSERs",
                column: "SuburbId");

            migrationBuilder.CreateIndex(
                name: "IX_Payments_NurseId",
                table: "Payments",
                column: "NurseId");

            migrationBuilder.CreateIndex(
                name: "IX_Requests_DependentId",
                table: "Requests",
                column: "DependentId");

            migrationBuilder.CreateIndex(
                name: "IX_Screenings_CaptureResultsCapId",
                table: "Screenings",
                column: "CaptureResultsCapId");

            migrationBuilder.CreateIndex(
                name: "IX_Screenings_DependentId",
                table: "Screenings",
                column: "DependentId");

            migrationBuilder.CreateIndex(
                name: "IX_Suburbs_CityId",
                table: "Suburbs",
                column: "CityId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Bios");

            migrationBuilder.DropTable(
                name: "FavouriteSuburb");

            migrationBuilder.DropTable(
                name: "lABUSERs");

            migrationBuilder.DropTable(
                name: "Payments");

            migrationBuilder.DropTable(
                name: "Requests");

            migrationBuilder.DropTable(
                name: "Screenings");

            migrationBuilder.DropTable(
                name: "Timeslots");

            migrationBuilder.DropTable(
                name: "Suburbs");

            migrationBuilder.DropTable(
                name: "Nurses");

            migrationBuilder.DropTable(
                name: "CaptureResult");

            migrationBuilder.DropTable(
                name: "Dependents");

            migrationBuilder.DropTable(
                name: "Citys");

            migrationBuilder.DropTable(
                name: "Aidtbl");

            migrationBuilder.DropTable(
                name: "Funds");
        }
    }
}
