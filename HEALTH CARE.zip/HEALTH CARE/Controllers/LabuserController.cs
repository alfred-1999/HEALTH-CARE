﻿using HEALTH_CARE.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HEALTH_CARE.Controllers
{
    public class LabuserController : Controller
    {

        private readonly ApplicationDbContext _db;

        public LabuserController(ApplicationDbContext db)
        {
            this._db = db;
        }


        public IActionResult labuser()
        {
            return View(_db.Screenings.ToList());
        }

        public IActionResult results()
        {
            return View(_db.Screenings.ToList());
        }
        public IActionResult dropofftest()
        {
            return View(_db.Screenings.ToList());
        }
        public IActionResult schedulebarcodes()
        {
            return View(_db.Screenings.ToList());
        }
        public async Task<IActionResult> recordresult(int? Id)
        {
            if (Id == null)
            {
                return NotFound();
            }

            var book = await _db.Screenings.SingleOrDefaultAsync(m => m.ScreeningId == Id);

            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }
        public async Task<IActionResult> testsresults(int? Id)
        {
            if (Id == null)
            {
                return NotFound();
            }

            var bio = await _db.Screenings.SingleOrDefaultAsync(m => m.ScreeningId == Id);


            if (bio == null)
            {
                return NotFound();
            }

            return View(bio);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> testsresults(int Id, Screening bio)
        {
            if (Id != bio.ScreeningId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {

                _db.Screenings.Update(bio);
                await _db.SaveChangesAsync();
                return RedirectToAction(nameof(testsresults));
            }

            return View(bio);
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _db.Dispose();
            }
        }

    }
}
