﻿using HEALTH_CARE.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HEALTH_CARE.Controllers
{
    public class NurseController : Controller
    {
        private readonly ApplicationDbContext _db;

        public NurseController(ApplicationDbContext db)
        {
            this._db = db;
        }
        public IActionResult Index()
        {
            return View(_db.Requests.ToList());
        }
        public IActionResult Schedule()
        {
            return View(_db.lABUSERs.ToList());
        }
        public IActionResult scheduletest()
        {         
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> scheduletest( LABUSER bio)
        {          
            if (ModelState.IsValid)
            {

                _db.Add(bio);
                await _db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(bio);
        }
        public IActionResult FavAddress()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> FavAddress(FavouriteSuburb bio)
        {
            if (ModelState.IsValid)
            {

                _db.Add(bio);
                await _db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(bio);
        }
        public IActionResult screening()
        {

            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> screening( Screening bio)
        {
            

            if (ModelState.IsValid)
            {

                _db.Add(bio);
                await _db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(bio);
        }
    }
}
