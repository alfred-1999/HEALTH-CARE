﻿using HEALTH_CARE.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HEALTH_CARE.Controllers
{
    public class PatientController : Controller
    {
        private readonly ApplicationDbContext _db;
        public PatientController(ApplicationDbContext db)
        {
            this._db = db;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult appointment()
        {
            ViewBag.DepName = new SelectList(_db.Dependents, "DepName", "DepName");
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> appointment(Request request)
        {
            if (ModelState.IsValid)
            {
                _db.Add(request);
                await _db.SaveChangesAsync();

                return RedirectToAction(nameof(appointment));
            }

            ViewBag.DepName = new SelectList(_db.Dependents, "DepName", "DepName", request.DepName);

            return View(request);
        }


        public IActionResult SignDependent()
        {
            
            ViewBag.MedicalPlan = new SelectList(_db.Aidtbl, "MedicalPlan", "MedicalPlan");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SignDependent(Dependent dependent)
        {
            if (ModelState.IsValid)
            {
                _db.Dependents.Add(dependent);
                await _db.SaveChangesAsync();

                return RedirectToAction(nameof(SignDependent));
            }

            ViewBag.MedicalPlan = new SelectList(_db.Aidtbl, "MedicalPlan", "MedicalPlan", dependent.MedicalPlan);

            return View(dependent);
        }

        public IActionResult manage()
        {
            return View(_db.Requests.ToList());
        }
        public IActionResult ownersbio()
        {
            return View(_db.Bios.ToList());
        }
        public async Task<IActionResult> reference(int? Id)
        {
            if (Id == null)
            {
                return NotFound();
            }

            var req = await _db.Requests.SingleOrDefaultAsync(m => m.RequestId == Id);

            if (req == null)
            {
                return NotFound();
            }

            return View(req);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _db.Dispose();
            }
        }
    }
}
