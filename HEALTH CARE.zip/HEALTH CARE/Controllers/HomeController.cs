﻿using HEALTH_CARE.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace HEALTH_CARE.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly ApplicationDbContext _db;

        public HomeController(ILogger<HomeController> logger, ApplicationDbContext db)
        {
            _logger = logger;
            _db = db;
        }

        public IActionResult Index()
        {
            
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(Bio reg, Bio log)
        {
            
            if(log.Username == "ONP4002021@gmail.com" || log.Username == "ONP4002021@gmail.com")
            {
                return RedirectToAction("appointment");
            }
            else if (log.Username == "Dorothy Daniels")
            {
                return RedirectToAction("nurse");
            }
            else if (log.Username == "maria@gmail.com")
            {
                return RedirectToAction("manager");
            }
            else if (log.Username == "lab@gmail.com")
            {
                return RedirectToAction("manager");
            }
            return View();

        }
        public IActionResult manager()
        {
            return View(_db.Requests.ToList());
        }
        public IActionResult nurse()
        {
            return View(_db.Requests.ToList());
        }
        public IActionResult registerpage()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> registerpage(Bio reg)
        {
            if (ModelState.IsValid)
            {
                _db.Add(reg);
                await _db.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }



            return View(reg);
        }
        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult appointment()
        {
            ViewBag.DepName = new SelectList(_db.Dependents, "DepName", "DepName");
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> appointment(Request request)
        {
            if (ModelState.IsValid)
            {
                _db.Add(request);
                await _db.SaveChangesAsync();

                return RedirectToAction(nameof(appointment));
            }

            ViewBag.DepName = new SelectList(_db.Dependents, "DepName", "DepName", request.DepName);

            return View(request);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
