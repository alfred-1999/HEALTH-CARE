﻿using HEALTH_CARE.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Rotativa;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HEALTH_CARE.Controllers
{
    public class ManagerController : Controller
    {
        private readonly ApplicationDbContext _db;

        public ManagerController(ApplicationDbContext db)
        {
            this._db = db;
        }
      
        public IActionResult Index()
        {
            var count = _db.Requests.Count();
            return View(_db.Requests.ToList());
        }
        public IActionResult TestPeformed()
        {
            return View(_db.Screenings.ToList());
        }
        public IActionResult ManagerPage()
        {
            ViewBag.MedicalAid = new SelectList(_db.Funds, "MedicalAid", "MedicalAid");
            return View();

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ManagerPage(MedicalAidtbl medical)
        {
            if (ModelState.IsValid)
            {
                _db.Aidtbl.Add(medical);
                await _db.SaveChangesAsync();

                return RedirectToAction(nameof(ManagerPage));
            }
            ViewBag.MedicalAid = new SelectList(_db.Funds, "MedicalAid", "MedicalAid", medical.MedicalAid);
            return View(medical);
        }
        public IActionResult medAid()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> medAid(MedicalAidFund med)
        {
            if (ModelState.IsValid)
            {
                _db.Add(med);
                await _db.SaveChangesAsync();

                return RedirectToAction(nameof(medAid));
            }

            return View(med);
        }
        public IActionResult HireEmployee()
        {
            return View();
        }
        public IActionResult Enquiry()
        {
            return View(_db.Screenings.ToList());
        }
        public IActionResult Payment()
        {
            return View();
        }





        public IActionResult request()
        {
            return View(_db.Requests.ToList());
        }

        public IActionResult testbooking()
        {
            return View(_db.lABUSERs.ToList());
        }

        public IActionResult TestPerformed()
        {
            return View(_db.lABUSERs.ToList());
        }
        public IActionResult HiringNurse()
        {
            ViewBag.SuburbName = new SelectList(_db.Suburbs, "SuburbName", "SuburbName");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> HiringNurse(Nurse nurse)
        {
            if (ModelState.IsValid)
            {
                _db.Nurses.Add(nurse);
                await _db.SaveChangesAsync();
                return RedirectToAction(nameof(HiringNurse));
            }
            ViewBag.SuburbName = new SelectList(_db.Suburbs, "SuburbName", "SuburbName", nurse.SuburbName);
            return View(nurse);
        }
        public IActionResult HiringLabUser()
        {
            ViewBag.SuburbName = new SelectList(_db.Suburbs, "SuburbName", "SuburbName");
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        //public async Task<IActionResult> HiringLabUser(LABUSER lab)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        _db.lABUSERs.Add(lab);
        //        await _db.SaveChangesAsync();
        //        return RedirectToAction(nameof(HiringLabUser));
        //    }
        //    ViewBag.SuburbName = new SelectList(_db.Suburbs, "SuburbName", "SuburbName", lab.SuburbName);
        //    return View(lab);
        //}
        public IActionResult PayLabUser()
        {
            return View();
        }
        public IActionResult PayNurse()
        {
            return View();
        }


        public IActionResult timeslot()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> timeslot(Timeslot time)
        {
            if (ModelState.IsValid)
            {
                _db.Add(time);
                await _db.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }

            return View(time);
        }

        public IActionResult Suburbs()
        {

            ViewBag.cityName = new SelectList(_db.Citys, "cityName", "cityName");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Suburbs(Suburb suburb)
        {
            if (ModelState.IsValid)
            {
                _db.Add(suburb);
                await _db.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }
            ViewBag.cityName = new SelectList(_db.Citys, "cityName", "cityName", suburb.cityName);

            return View(suburb);
        }

        public IActionResult Cities()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Cities(City city)
        {
            if (ModelState.IsValid)
            {
                _db.Add(city);
                await _db.SaveChangesAsync();

                return RedirectToAction(nameof(Cities));
            }

            return View(city);
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                this._db.Dispose();
            }
        }
    }
}
