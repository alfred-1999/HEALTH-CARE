﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HEALTH_CARE.Models
{
    public class Nurse
    {
        [Key]
        public int NurseId { get; set; }

        [Required]
        public string FullName { get; set; }
        [Required]
        public string Surname { get; set; }
        [Required]
        public string CellNumber { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]

        public string Date { get; set; }

        [Required]
        public string SuburbName { get; set; }

        //public virtual Suburb Suburb { get; set; }
        ////public string Addresses { get; set; }   

        public virtual ICollection<Payment> Payments { get; set; }

    }
}
