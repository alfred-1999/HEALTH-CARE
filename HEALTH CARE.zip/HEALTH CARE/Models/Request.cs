﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HEALTH_CARE.Models
{
    public class Request
    {
        [Key]
        public int RequestId { get; set; }
        [Required]
        public string Testfor { get; set; }
        [Required]
        public string TodaysDate { get; set; }
        public string NewAddress { get; set; }
        [Required]
        public string MainFullName { get; set; }
        [Required]
        public string IDNo { get; set; }
        
        public string Time { get; set; }

        //Edited portion
        [Required]
        public string MediStatus { get; set; }
        [Required]
        public string Status { get; set; }

        [Required]
        public string Email { get; set; }



        //Edited
        //[DisplayName("NurseId")]
        //public string Date { get; set; }
        //public string NurseName { get; set; }
        //public virtual Nurse Nurse { get; set; }

        public string DepName { get; set; }
        public virtual Dependent Dependent { get; set; }



        

        //public virtual ICollection<Schedule> Schedules { get; set; }
              
        
    }
}
