﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HEALTH_CARE.Models
{
    public class ApplicationDbContext : DbContext
    {
    
        public DbSet<Bio> Bios { get; set; }
        public DbSet<City> Citys { get; set; }
        public DbSet<CaptureResults> CaptureResult { get; set; }
        public DbSet<Dependent> Dependents { get; set; }
        public DbSet<FavouriteSuburb> Favs { get; set; }
        public DbSet<LABUSER> lABUSERs { get; set; }
        public DbSet<MedicalAidFund> Funds { get; set; }
        public DbSet<MedicalAidtbl> Aidtbl { get; set; }
        public DbSet<Nurse> Nurses { get; set; }
        public DbSet<Request> Requests { get; set; }
        public DbSet<Screening> Screenings { get; set; }
        public DbSet<FavouriteSuburb> FavouriteSuburbs { get; set; }
        public DbSet<Suburb> Suburbs { get; set; }
      
        public DbSet<Payment> Payments { get; set; }
        public DbSet<Timeslot> Timeslots { get; set; }
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }
    }
}
