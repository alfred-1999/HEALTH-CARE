﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HEALTH_CARE.Models
{
    public class MedicalAidFund
    {
        [Key]
        public int FundId { get; set; }
        [Required]
        public string MedicalAid { get; set; }
        public virtual ICollection<MedicalAidtbl> MedicalAidtbls { get; set; }
    }
}
