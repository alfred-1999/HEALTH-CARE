﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HEALTH_CARE.Models
{
    public class Suburb
    {
        [Key]
        public int SuburbId { get; set; }

        [Required]
        public string SuburbName { get; set; } 

        [DisplayName("City Id")]
        public string cityName { get; set; }
        public virtual City City { get; set; }

        public virtual ICollection<FavouriteSuburb> FavouriteSuburbs { get; set; }

        //public virtual ICollection<Bio> Bios { get; set; }
        
        public virtual ICollection<LABUSER> LABUSER { get; set; }
    }
}
