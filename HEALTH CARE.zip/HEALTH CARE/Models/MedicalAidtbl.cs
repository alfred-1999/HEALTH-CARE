﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HEALTH_CARE.Models
{
    public class MedicalAidtbl
    {
        [Key]
        public int MedicalId { get; set; }
        //public string Description { get; set; }
        //[Required]
        //public string MedicalType { get; set; }
        [Required]
        public string MedicalPlan { get; set; }


        public string MedicalAid { get; set; }
        public virtual MedicalAidFund MedicalAidFund { get; set; }

        //public virtual ICollection<Bio> Bios { get; set; }

        public virtual ICollection<Dependent> Dependents { get; set; }
    }
}
