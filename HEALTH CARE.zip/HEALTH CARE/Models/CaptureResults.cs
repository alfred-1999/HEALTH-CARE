﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HEALTH_CARE.Models
{
    public class CaptureResults
    {
        [Key]
        public int CapId { get; set; }

        // public string Barcode { get; set; }
        // public virtual Barcodes Barcodes { get; set; }
        [Required]
        public string Results { get; set; }

        public virtual ICollection<Screening> Screenings { get; set; }
    }
}
