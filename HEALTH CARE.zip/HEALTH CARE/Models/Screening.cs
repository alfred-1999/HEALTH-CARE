﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HEALTH_CARE.Models
{
    public class Screening
    {
        [Key]
        public int ScreeningId { get; set; }

        [Required]
        public string Patient { get; set; }
        [Required]
        public string Temperature { get; set; }
        [Required]
        public string BloodPressure { get; set; }
        [Required]
        public int Oxygen { get; set; }

        [Required]
        public string Barcode { get; set; }

        [Required]
        public string IDNo { get; set; }

        public string Results { get; set; }
        public virtual CaptureResults CaptureResults { get; set; }

        ////public string IDNo { get; set; }
        //public virtual Dependent Dependent { get; set; }

        //public virtual ICollection<Cap> Barcodess { get; set; }
    }
}
