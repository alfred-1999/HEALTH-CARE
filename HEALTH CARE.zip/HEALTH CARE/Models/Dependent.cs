﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HEALTH_CARE.Models
{
    public class Dependent
    {
        [Key]
        public int DependentId { get; set; }
        [Required]
        public string IDNo { get; set; }
        [Required]
        public string DepName { get; set; }
        [Required]
        public string DepSurname { get; set; }
        [Required]
        public string Cellphone { get; set; }
        [Required]
        public string Email { get; set; }
        public string DependentAddress { get; set; }

        public string Description { get; set; }

        public string MedicalType { get; set; }

        public string MedicalNo { get; set; }
        public string Owner { get; set; }

        public string MedicalPlan { get; set; }
        public virtual MedicalAidtbl MedicalAidtbl { get; set; }

        public virtual ICollection<Request> Requests { get; set; }

        public virtual ICollection<Screening> Screenings { get; set; }
    }
}
