﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HEALTH_CARE.Models
{
    public class FavouriteSuburb
    {
        [Key]
        public int FavId { get; set; }
        //public string Fav { get; set; }

        public string NurseName { get; set; }

        public string SuburbName { get; set; } //+ PostalCode
        public virtual Suburb Suburb { get; set; }
    }
}
