﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HEALTH_CARE.Models
{
    public class City
    {
        [Key]
        public int CityId { get; set; }
        [Required]
        public string cityName { get; set; }
        public virtual ICollection<Suburb> Suburbs { get; set; }
    }
}
