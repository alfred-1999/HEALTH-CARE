﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HEALTH_CARE.Models
{
    public class Schedule
    {
        [Key]
        public int ScheduleId { get; set; }
        [Required]
        public string NurseName { get; set; }

        [Required]
        public string DateSchedule { get; set; }

        
        public string RequestId { get; set; }
        public virtual Request Request { get; set; }

        public string TimeRange { get; set; }
        public virtual Timeslot Timeslot { get; set; }
    }
}
