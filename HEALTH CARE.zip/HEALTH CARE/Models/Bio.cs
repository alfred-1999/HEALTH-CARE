﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace HEALTH_CARE.Models
{
    public class Bio
    {
        [Key]
        public int BioId { get; set; }

        [Required]
        public string Username { get; set; }
        [Required]
        public string Password { get; set; }
        //[Required]
        //public string ConfirmPassword { get; set; }


        [Required]
        public string Name { get; set; }
        [Required]
        public string Surname { get; set; }
        [Required]
        public string IDNo { get; set; }
        
        public string Cellphone { get; set; }

        public string MedicalNo { get; set; }

        public string Owner { get; set; }

        //[DisplayName("Suburb Id")]
        public string SuburbName { get; set; } /*+ PostalCode*/

        //public string PostalCode { get; set; }
        //public string cityName { get; set; }
        //public virtual Suburb Suburb { get; set; }


        public string MedicalType { get; set; }
        public string MedicalPlan { get; set; }
        //public virtual MedicalAidtbl MedicalAidtbl { get; set; }

      
    }
}
